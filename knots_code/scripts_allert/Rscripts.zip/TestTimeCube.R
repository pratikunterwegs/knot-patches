#' ---
#' title: "Space-time cube"
#' author: "John Fieberg"
#' date: ""
#' ---

#'  ## Space-time cube

#' This code provides an example of how you can construct a space-time cube in R.
#' See: https://cran.r-project.org/web/packages/rgl/vignettes/rgl.html for more on the
#' rgl package.
#+ warning=FALSE, message=FALSE 
library(rgl)
library(tidyverse)
library("htmltools", "rglwidget")

#' Read in data.  
#' Read in annotated available data for RSF modeling
ssfdat<-read.csv("data/AllStepsFisher2018-EnvDATA-results.csv")

#' Convert time variables
ssfdat$t1_<-as.POSIXct(ssfdat$t1_, format="%Y-%m-%d %H:%M:%OS", tz="UTC")
ssfdat$t2_<-as.POSIXct(ssfdat$t2_, format="%Y-%m-%d %H:%M:%OS", tz="UTC")


#' Simplify some variable names and make case a numeric variable
names(ssfdat)[c(16,21,20,22)]<-c("id","Elevation", "LandClass", "PopDens")
ssfdat$case_<-as.numeric(ssfdat$case)

#' Create landcover classes (as suggested by Scott Lapoint :)
ssfdat$LandClass<-as.character(ssfdat$LandClass)
ssfdat<-ssfdat %>% mutate(landC = fct_collapse(LandClass,
                                               agri = c("11", "14", "30"),
                                               forest =c("30","40","50","60", "70","80", "90","100"),
                                               shrub= c("110", "130", "150"),
                                               grass = c("120", "140"),
                                               wet= c("160"),
                                               other = c("170", "180", "190", "200", "210", "220")))

#' ## Display space-time cube. 
martenF1<-subset(ssfdat, id=="F1")
martenF1<-martenF1[order(martenF1$timestamp),]

#' **Try clicking on the cube with your mouse - you should be able to rotate it!**
with(martenF1, plot3d(location.long,location.lat,timestamp, type="l", col=as.integer(martenF1$landC)))
(stcube<-with(martenF1, plot3d(location.long,location.lat,timestamp, type="l", 
                                       col=as.numeric(cut(martenF1$Elevation,5)), alpha=0.4)))
rglwidget() 
 

 