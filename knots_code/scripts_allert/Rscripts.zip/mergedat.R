#' ---
#' title: "Merge Data"
#' author: "John Fieberg"
#' date: ""
#' ---
#' 
#' 
#' ### Preamble
#' 
#' **Purpose**: Merge together original Use/available data with annotated Env-Data.
#'  
#' Load libraries
#+warning=FALSE, message=FALSE
library(ezknitr)
library(knitr)
library(lubridate)
library(raster)
library(move)
library(amt) 
library(tidyverse)
options(width=150)

## RSF data

#' Read in original data (used and available points) and merge on environmental
#' data.
rsfdattemp<-read.csv("data/FisherRSF2018.csv")
annotated<-read.csv("data/FisherRSFannotate.csv-6951661009794024140.csv")

#' Now, merge these by "timestamp", "location-long", "location-lat")
rsfdat<-merge(rsfdattemp, annotated)

#' Write out data for use in FisherRSF2018.R
write.csv(rsfdat, "data/FisherRSF2018-EnvDATA-results.csv", row.names = FALSE)

## SSF data

#' Read in original data (used and available points) and merge on environmental
#' data.
ssfdattemp<-read.csv("data/AllStepsFisher2018.csv")
annotated<-read.csv("data/FisherSSFannotate.csv-1402112999909362686.csv")

#' Now, merge these by "timestamp", "location-long", "location-lat")
ssfdat<-merge(ssfdattemp, annotated)


#' Write out data for use in FisherSSF2018.R
write.csv(ssfdat, file="data/AllStepsFisher2018-EnvDATA-results.csv", row.names=FALSE)
